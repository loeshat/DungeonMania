package dungeonmania.mvp;

public class DungeonResponse {

}
