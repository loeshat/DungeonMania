package dungeonmania.entities.collectables.bombs;

public class InventoryBombState extends BombState {

    public InventoryBombState() {
        super();
    }
}
