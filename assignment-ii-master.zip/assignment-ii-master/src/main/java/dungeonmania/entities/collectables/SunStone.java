package dungeonmania.entities.collectables;

import dungeonmania.util.Position;

public class SunStone extends Collectable {
    public SunStone(Position position) {
        super(position);
    }
}
