package dungeonmania.entities.collectables.bombs;

public class PlacedBombState extends BombState {

    public PlacedBombState() {
        super();
    }
}
